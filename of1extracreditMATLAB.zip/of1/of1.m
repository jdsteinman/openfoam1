clc
clear
sre10=importdata('vS/vS10/line1_U.xy');
sre71=importdata('vS/vS71.25/line1_U.xy');
sre132=importdata('vS/vS132.5/line1_U.xy');
sre193=importdata('vS/vS193.75/line1_U.xy');
sre255=importdata('vS/vS255/line1_U.xy');
sre316=importdata('vS/vS316.25/line1_U.xy');
sre377=importdata('vS/vS377.5/line1_U.xy');
sre438=importdata('vS/vS438.75/line1_U.xy');
sre500=importdata('vS/vS500/line1_U.xy');

Reynold = [ 10 71.25 132.5 193.75 255 316.25 377.5 438.75 500];
forceS = zeros(9,1);

forceS(1) = sum((1- sre10(:,4))/0.001);
forceS(2) = sum((1- sre71(:,4))/0.001);
forceS(3) = sum((1- sre132(:,4))/0.001);
forceS(4) = sum((1- sre193(:,4))/0.001);
forceS(5) = sum((1- sre255(:,4))/0.001);
forceS(6) = sum((1- sre316(:,4))/0.001);
forceS(7) = sum((1- sre377(:,4))/0.001);
forceS(8) = sum((1- sre438(:,4))/0.001);
forceS(9) = sum((1- sre500(:,4))/0.001);

forceS = 0.1*forceS;

plot(Reynold,forceS, '-o')
title("Force(tilde) vs Reynold's number for H/L=0.5")
xlabel("Re")
ylabel('non-dimensional Force')

tre10=importdata('vT/vT10/line1_U.xy');
tre71=importdata('vT/vT71.25/line1_U.xy');
tre132=importdata('vT/vT132.5/line1_U.xy');
tre193=importdata('vT/vT193.75/line1_U.xy');
tre255=importdata('vT/vT255/line1_U.xy');
tre316=importdata('vT/vT316.25/line1_U.xy');
tre377=importdata('vT/vT377.5/line1_U.xy');
tre438=importdata('vT/vT438.75/line1_U.xy');
tre500=importdata('vT/vT500/line1_U.xy');

forceT = zeros(9,1);

forceT(1) = sum((1- tre10(:,4))/0.001);
forceT(2) = sum((1- tre71(:,4))/0.001);
forceT(3) = sum((1- tre132(:,4))/0.001);
forceT(4) = sum((1- tre193(:,4))/0.001);
forceT(5) = sum((1- tre255(:,4))/0.001);
forceT(6) = sum((1- tre316(:,4))/0.001);
forceT(7) = sum((1- tre377(:,4))/0.001);
forceT(8) = sum((1- tre438(:,4))/0.001);
forceT(9) = sum((1- tre500(:,4))/0.001);

forceT = 0.2*forceT;

figure(2)
plot(Reynold,forceT, '-o')
title("Force(tilde) vs Reynold's number for H/L=2")
xlabel("Re")
ylabel('non-dimensional Force')




